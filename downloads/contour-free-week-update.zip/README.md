# Add the no-card free week

A new customer can claim **seven days of all Pro tools** through a $0 one-time product. This creates a free order, not a subscription. After seven days the editor locks. The customer must deliberately buy the monthly or annual subscription to continue; the trial never automatically charges a card. A paid plan starts billing when purchased, even if the trial has time left.

Everything runs in your Shopify theme, Shopify checkout, and Shopify Flow. Your existing paid workflow stays on and unchanged. Trial access uses a separate customer metafield, so trial claims cannot overwrite paid access.

## 1. Create the trial product as a draft

In **Products → Add product**, use:

| Setting | Value |
| --- | --- |
| Title | Contour Studio — Free Week |
| Price | 0.00 |
| SKU | `CONTOUR-TRIAL-7DAY` |
| Physical product / shipping | Off |
| Track quantity | Off |
| Subscription / selling plans | None; this is a one-time product |
| Status | Draft until the trial workflow is ready |

Do not attach the monthly or annual subscription plan to this product. Keep it out of regular collections and navigation; the Contour page offers the claim link. The trial product must be genuinely $0, rather than a paid product discounted to free.

## 2. Create one customer field

**Settings → Metafields and metaobjects → Customers → Add definition**:

- Name: **Contour trial until**.
- Namespace and key: **`contour.trial_until`**.
- Type: **One value → Integer**, not a list.

Leave customer values empty until Flow grants the trial. Do not let customers edit this field.

## 3. Make a separate trial workflow

Duplicate the working paid-access workflow in Shopify Flow. Name the copy **Contour — Free Week** and keep the copy **off** while editing. Keep the original paid workflow on.

In the copy:

1. Keep the **Order paid** trigger. Shopify should mark a completed $0 checkout as paid; confirm this on your store during testing.
2. Open **Run code** and replace all three boxes using the trial files:
   - Input query: `flow/trial-input.graphql`.
   - Output schema: `flow/trial-output.graphql`.
   - Code: `flow/trial-access.js`.
3. Keep the condition **Run code → eligible → equals true**.
4. On **True**, open **Send Admin API request**. Keep the mutation **metafieldsSet**. Delete the whole mutation-input value and paste only the contents of `flow/trial-mutation.json.liquid`.
5. Confirm the inserted variables refer to this copy's Run code action. If Flow names it differently from `runCode`, use its variable picker to replace `runCode.trialUntil` with the actual trial output.
6. Save and turn on the trial workflow once its configuration has no errors. The API request cannot be fully simulated by Flow's preview; verify a real $0 trial checkout on a test customer after the following theme steps.

The mutation type is `number_integer`, not `list.number_integer`. The JSON contains **one** `metafields` object, not a second default template appended after it. Keep **`"compareDigest": null`** exactly as provided: it makes this a create-only write. Two concurrent claims cannot overwrite an existing trial expiry. A duplicate concurrent request can show a compare-digest error in Flow while the first claim succeeds; verify the existing trial value rather than removing this safeguard.

Eligibility is one trial per customer account, not per human. An account with any paid-access record (even a revoked value of zero), or any previous trial record, cannot claim a trial. A customer who bought unrelated store products can qualify if they have never had Contour access. The workflow requires a single non-shipping, one-time trial item, quantity one, original item price $0, order total $0, and an attached customer. Mixed, paid, recurring, and anonymous orders do not grant a trial.

## 4. Update the existing theme

Use **contour-free-week-update.zip** if Contour Studio is already installed. It contains only the two theme files to replace, the new trial Flow files, and this guide.

1. Back up your current theme.
2. Replace **Assets → `contour-shopify.js`** with the update's file of that name.
3. Replace **Sections → `contour-studio.liquid`** with the update's file of that name.
4. Save both. If the code editor reports missing snippet files that are already present, save and reload the editor so Theme Check refreshes its index.

Leave your existing page template and subscription-card snippet in place. Replacing the page template with a blank copy would reset your selected monthly/annual product settings. No fonts, PDF settings, or existing paid Flow code need changing for this update.

Then:

5. Make the trial product **Active** and available to the **Online Store** channel.
6. In **Edit theme → Pages → contour-studio → Contour Studio · Paid**, select it under **Optional free-week product**, then save.
7. Open the storefront page in a new customer session to test. Your paid test account will continue seeing its paid editor and will not show a trial claim button.

## 5. Test the actual store

1. Use a **new test customer** that has neither `contour.access_until` nor `contour.trial_until` set. Do not remove a real subscriber's paid access to test this.
2. Open the Contour Studio page and sign in. Choose **Start my free week**.
3. The link opens Shopify's native cart permalink with the one free trial variant. Confirm the checkout contains only that product, has a $0 total, no recurring plan, no shipping, and requires no payment card. Complete checkout.
4. Check the trial workflow's actual run and the customer's **Contour trial until** value. Return to the Contour page and refresh. The editor should open with a **Free trial** badge and a days-left notice.
5. Export a PDF and verify it in VersaWorks. Try claiming again; it must not reset the trial. No subscription contract should have been created by the $0 order.
6. On this test account only, record the trial timestamp, then set it to `1` to simulate expiration. Refresh: the editor should lock, the trial claim button should disappear, and paid plans should remain available. Leave the field present: deleting it would make the account eligible again if it has no paid access.
7. Separately test an explicit paid subscription purchase using the store's appropriate payment test process. The existing paid workflow should write `contour.access_until`; the editor should show paid access. The trial field stays separate. Recurring billing still needs its own test if you have only checked checkout prices so far.

To revoke trial access, set `contour.trial_until` to `0`; keep the field present to preserve the once-only record. To revoke all access on a customer who also has paid access, review and revoke **both** access fields according to your refund/cancellation policy. Shopify administrators can manually delete or edit the trial record; this is not strong software licensing or person-level anti-abuse protection.

The seven days run from the $0 order's creation time, in seconds, with no renewal grace added. Delayed/retried workflow execution does not restart the clock. Browser exports recheck the store's effective paid/trial access; the full workspace and existing downloads remain subject to the browser-only copy-protection limitation described in the main guide.

## Validation scope

Local unit and browser tests cover trial eligibility, exact duration, rejection of repeat claims and paid/shipping/subscription products, separate expiry fields, create-only mutation configuration, trial UI, PDF exports, expiry lockout, and paid upgrade. Checkout and Flow responses are local fixtures. The native $0 checkout, Flow input fields, and mutation must still be verified on your Shopify store before advertising the trial. These files do not change your live store automatically.
