// Separate Shopify Flow: Order paid -> Run code -> eligible true ->
// metafieldsSet with trial-mutation.json.liquid. The paid workflow stays unchanged.
export default function main(input) {
  const noTrial = { eligible: false, trialUntil: '0' };
  const order = input.order;
  if (!order?.customer?.id || !Array.isArray(order.lineItems)) return noTrial;
  // A standalone $0, non-shipping, one-time trial order never creates a
  // subscription contract or authorizes a future charge.
  if (order.lineItems.length !== 1) return noTrial;
  const item = order.lineItems[0];
  if (item.sku !== 'CONTOUR-TRIAL-7DAY' || item.quantity !== 1 || item.requiresShipping !== false || item.sellingPlan != null || item.product?.requiresSellingPlan !== false) return noTrial;
  const zero = value => value === 0 || (typeof value === 'string' && /^0+(?:\.0+)?$/.test(value));
  if (!zero(order.totalPriceSet?.shopMoney?.amount) || !zero(item.originalUnitPriceSet?.shopMoney?.amount)) return noTrial;
  if (!Array.isArray(order.customer.metafields)) throw new Error('Include customer metafields in the trial input query.');
  const fields = order.customer.metafields;
  if (fields.some(field => field.namespace === 'contour' && field.key === 'trial_until')) return noTrial;
  const paid = fields.find(field => field.namespace === 'contour' && field.key === 'access_until');
  // A paid-access record, including a revoked value of zero, makes this an
  // existing/former member. Removing that history is an administrator action.
  if (paid) return noTrial;
  if (typeof order.createdAt !== 'string' || !/Z$|\+00:00$/.test(order.createdAt)) throw new Error('Expected a UTC trial order timestamp.');
  const start = Date.parse(order.createdAt);
  if (!Number.isFinite(start) || start < 0 || start > 7258118400000) throw new Error('Invalid trial order timestamp.');
  const trialUntil = Math.floor(start / 1000) + 7 * 24 * 60 * 60;
  return { eligible: true, trialUntil: String(trialUntil) };
}
