# Shopify-only paid Contour Studio

This edition runs entirely through your Shopify store and Shopify's own services. No Netlify, Supabase, Stripe account, GitHub deployment, API key, external database, or externally hosted app is required. It is a theme tool for your customers, not a custom app that needs a separate server. Shopify hosts the theme files, customer login, checkout, and subscription management; all image tracing and PDF generation happen in the browser.

There is **no Free tier**. Both plans include unlimited exports, up to 500 designs per batch, advanced contours, and presets saved on the customer's device:

| Product | Price | Recurring billing |
| --- | --- | --- |
| Pro | CAD $7.99 | Every month |
| Annual Pro | CAD $79.99 | Every 12 months |

Shopify Payments handles checkout payment processing. Shopify's **Shopify Subscriptions** app creates the recurring plans; **Shopify Flow** grants paid access after a successful payment. These are Shopify apps managed from your store admin. Shopify plan fees, supported payment methods, and your store's eligibility still apply. This package does not install apps, create products, or activate payments automatically.

## 1. Set up recurring products in Shopify

1. Enable Shopify Payments for your business and set your store currency to CAD if these are your Canadian-dollar base prices.
2. Install Shopify's own **Shopify Subscriptions** and **Shopify Flow** apps from Shopify's App Store. You do not need to publish your own app.
3. Create two products with **one variant each**. Mark them as not requiring physical shipping. Use these exact, unique SKUs:
   - Monthly: `CONTOUR-PRO-MONTHLY`, CAD 7.99.
   - Annual: `CONTOUR-PRO-ANNUAL`, CAD 79.99.
4. In Shopify Subscriptions, attach a monthly recurring plan to the monthly product, and a 12-month recurring plan to the annual product. Avoid discounts if you want exactly the prices above.
5. Set **both products to subscription-only / require a selling plan**. Remove one-time purchase options. The included purchase forms refuse to sell products that permit one-time purchase. Publish both products to the Online Store channel.
6. Configure your customer accounts and the Shopify Subscriptions customer-management links. Customers need to log in with the same email they used for subscription checkout. Check that their account actually offers management/cancellation before launch.
7. Configure your cancellation, refund, failed-payment, tax, and recurring-payment disclosures. Customers purchase the subscription through Shopify checkout, which creates the real subscription contract. Adding a product to the cart alone does not grant access.

Shopify's admin labels can vary by theme and account setup. Validate that your store and Shopify Subscriptions support your intended non-shipping membership products before accepting live payments. If your account does not offer the required selling-plan configuration, leave the membership page unpublished; this theme cannot create recurring contracts by itself.

## 2. Configure paid-access automation inside Shopify

The editor reads a **customer** metafield, `contour.access_until`, containing integer Unix seconds. Liquid grants access only to a logged-in customer whose timestamp is in the future. Missing, expired, zero, and invalid values stay locked. A successful checkout URL or a browser flag never grants membership.

1. In **Settings → Custom data → Customers**, add a definition named **Contour access until**, namespace/key **`contour.access_until`**, type **Integer**. Do not allow customer edits to this field. It does not need public Storefront API access.
2. Create a Shopify Flow workflow triggered by **Order paid**. Never use Order created, checkout completion, or subscription-contract creation to grant access: those do not prove payment.
3. Add a **Run code** action. Paste the included files into its corresponding fields:
   - Input query: `flow/input.graphql`.
   - Output schema: `flow/output.graphql`.
   - JavaScript: `flow/paid-access.js`.
4. Add a condition: **Run code → eligible** equals **true**, and the order has a customer. Other products must not grant access. The supplied code also requires the product to be subscription-only; a matching SKU on a one-time or deleted product is rejected.
5. Before writing, compare the customer's existing `contour.access_until` with the numeric **Run code → accessUntilNumber** output. Update only when the current value is blank or smaller than the proposed value. Use Flow's customer-metafield variable picker to select the definition you created. This protects annual access from an older monthly order and repeated/delayed runs. Test the comparison with your store's Flow variable types; the value is an integer timestamp, not a lexical string comparison.
6. Add **Update customer metafield**. Select the order's customer, namespace `contour`, key `access_until`, type Integer, and choose **Run code → accessUntil** from the variable picker as its value. Use the output of this action, not a fixed number copied from a test.
7. Test the workflow with your own test subscription order, verify the timestamp on that customer, and activate it only after the tests below pass. If a field or action is unavailable on your store, resolve that configuration in Shopify before launch; the package intentionally fails closed until this automation grants access.

The code grants one calendar month or twelve calendar months from the paid order's **creation timestamp**, clamping month-end dates (January 31 → February 28/29), then adds a renewal grace period of **three days for monthly** or **one day for annual**. This prevents premature lockout when a subscription anchored on the 31st renews in February and returns to the 31st in March. Include this access grace period in your membership terms; it does not change the Shopify billing date or create a Free plan. Replaying the same order computes the same expiry. Each successfully paid recurring order renews access. Delayed payments do not restart the billing period from the later payment date. No external webhook receiver is used.

Cancellation or pause stops future successful renewals; access lasts until the existing paid-through timestamp, including the documented renewal grace period. Failed renewal payments do not extend access. For an immediate revocation or a refunded membership, set this customer's `contour.access_until` to `0` in Shopify. Refunds do not automatically revoke access in this package; create and verify a separate Flow if you want that policy automated. Avoid duplicate simultaneous subscriptions for one customer. When upgrading monthly to annual, cancel the superseded contract to prevent double billing.

## 3. Install the theme files

Use the **Shopify-only ZIP**, not the previous hosted-app embed kit or owner-site ZIP. The Shopify-only archive contains these folders:

- `assets/`: compiled JavaScript, CSS, and self-hosted fonts.
- `sections/contour-studio.liquid`: paid-access gate and workspace.
- `snippets/contour-plan-card.liquid`: real subscription cart forms.
- `templates/page.contour-studio.json`: dedicated page template.
- `flow/`: the configuration/code for the native Flow automation.
- `README.md`: these instructions.

1. In **Online Store → Themes**, duplicate your current theme and edit the duplicate first.
2. Open **Edit code**. Upload every file from the ZIP's `assets/` folder into theme **Assets**. Keep each filename exactly as supplied; there are no remote app scripts, CDN libraries, or provider keys to configure.
3. Create or replace the section and snippet with the supplied files. Add the supplied page template, preserving any existing page template you want to keep under a different name. If your editor cannot upload a particular asset type, use Shopify's theme-file upload tooling or a theme developer to upload the files to the theme; no external runtime is needed.
4. In **Online Store → Pages**, create **Contour Studio** and assign the `contour-studio` template. Open that template in **Customize / Edit theme**, select **Contour Studio · Paid**, and select your monthly and annual subscription products. Keep other public copies of the editor off your storefront.
5. Preview while logged out and while logged in with a paid test customer. Add the page to your navigation and publish the theme only after the checks below pass.

This is an integration kit, **not a complete theme**; do not upload the whole ZIP as a replacement theme. Shopify's code editor may require you to add assets individually. Existing Online Store 2.0 theme layouts and navigation remain in your current theme.

## 4. Verify before charging real customers

- Logged out: only paid plan cards and Shopify account sign-in appear; no Free plan or editor assets load.
- Logged in without a current paid-through value: editor stays locked, even with `?checkout=success` or altered local storage.
- Both purchase buttons post to Shopify's cart with the actual variant ID **and selling-plan ID**. The checkout must show the correct CAD amount and monthly/yearly recurrence. A one-time product must never unlock the editor.
- Successful test subscription payment: Flow grants the correct customer and only that customer; refresh the page to open the workspace. Test both plans, a renewal, a failed payment, replaying an order, and an older monthly order after an annual purchase.
- Cancellation: recurring billing stops; existing access expires at the stored paid-through time. Test a refund and your chosen revocation policy separately.
- Expired access: refresh locks the page. An already-open editor checks Shopify again on focus, every five minutes, and before each export; an unavailable membership check blocks new exports. Existing downloads can still be saved before refreshing.
- Import transparent PNG/SVG, export PDF, and verify CutContour recognition in your VersaWorks 7.6.1.3202. Test a representative 500-design batch on the device you intend to support. Presets are per device, not synced to a Shopify account.
- Test desktop/mobile, browser storage restrictions, your theme's content-security policy, and its account/subscription-management links. The editor needs browser IndexedDB, blob workers (`worker-src blob:` if your CSP restricts workers), Shopify-hosted assets/fonts, and same-origin page requests. It sends no artwork to a service.

Local tests cover the actual theme gate, cart form fields, worker tracing, PDF output, and the Flow date calculation. They cannot establish that your store's subscription checkout, renewal billing, Flow actions, or payment account are configured. **Subscriptions are not live merely because these files exist.**

## Access limitation

Shopify theme assets are public browser files. Liquid restricts which customers receive the editor page, but an authorized person can copy downloaded code or keep an offline copy. This offers storefront membership access, not strong software licensing or copy protection. The all-Shopify/browser-only design has no private server that can enforce a license on copied code.

## Developer packaging

`npm run package:shopify` builds the Shopify-only edition and creates `downloads/contour-shopify-only.zip`. It forcibly disables external billing and emits inline blob workers so JavaScript served from Shopify's asset CDN can still process files on the store origin. It does not publish anything or require GitHub. `npm run test:shopify` tests this edition; `test:shopify-embed` is the separate legacy external-hosted integration test.
