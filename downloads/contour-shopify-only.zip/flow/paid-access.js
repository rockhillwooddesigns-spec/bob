// Paste into Shopify Flow's "Run code" action after the "Order paid" trigger.
// Pure calendar arithmetic: no network, Date API, secrets, or external service.
export default function main(input) {
  const order = input.order;
  if (!order || !Array.isArray(order.lineItems)) throw new Error('Expected a paid order with line items.');
  let months = 0;
  for (const item of order.lineItems) {
    if (item.product?.requiresSellingPlan !== true) continue;
    if (item.sku === 'CONTOUR-PRO-ANNUAL') months = 12;
    else if (item.sku === 'CONTOUR-PRO-MONTHLY' && months === 0) months = 1;
  }
  if (!months || !order.customer?.id) return { eligible: false, accessUntil: '0' };
  if (!Array.isArray(order.customer.metafields)) throw new Error('Update the input query to include customer metafields.');
  const saved = order.customer.metafields.find(field => field.namespace === 'contour' && field.key === 'access_until');
  const current = saved ? Number(saved.value) : 0;
  if (!Number.isSafeInteger(current) || current < 0) throw new Error('Customer access_until must be a non-negative integer.');
  const timestamp = /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2})(?:\.\d+)?(?:Z|\+00:00)$/.exec(order.createdAt);
  if (!timestamp) throw new Error('Expected Shopify order.createdAt in UTC ISO format.');
  const [, y, m, d, hour, minute, second] = timestamp.map(Number);
  if (y < 1970 || y > 2200 || m < 1 || m > 12 || d < 1 || d > 31 || hour > 23 || minute > 59 || second > 59) throw new Error('Invalid paid order timestamp.');
  const leap = year => year % 4 === 0 && (year % 100 !== 0 || year % 400 === 0);
  const monthDays = year => [31, leap(year) ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  if (d > monthDays(y)[m - 1]) throw new Error('Invalid paid order calendar date.');
  const targetMonth = m - 1 + months;
  const year = y + Math.floor(targetMonth / 12), month = targetMonth % 12;
  const day = Math.min(d, monthDays(year)[month]);
  let days = 0;
  for (let prior = 1970; prior < year; prior++) days += leap(prior) ? 366 : 365;
  for (let prior = 0; prior < month; prior++) days += monthDays(year)[prior];
  days += day - 1;
  // Month-end renewal anchors can return to the 31st after February.
  // Keep access through that renewal without requiring a private contract API.
  const graceDays = months === 1 ? 3 : 1;
  const expiry = (days + graceDays) * 86400 + hour * 3600 + minute * 60 + second;
  const accessUntil = Math.max(expiry, current);
  return { eligible: true, accessUntil: String(accessUntil), accessUntilNumber: accessUntil };
}
